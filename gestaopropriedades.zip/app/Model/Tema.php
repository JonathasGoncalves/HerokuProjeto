<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Tema extends Model
{
    //
    protected $table = 'tema';

    
}
